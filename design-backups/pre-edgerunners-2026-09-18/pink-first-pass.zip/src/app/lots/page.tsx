import type { Metadata } from "next";
import Link from "next/link";
import { Footer } from "@/components/site/Footer";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Reveal } from "@/components/site/Reveal";
import { LotCard } from "@/components/lot/LotCard";
import { Pagination } from "@/components/lot/Pagination";
import { getLiveLots, getResultLots, getUpcomingLots } from "@/lib/api";
import { t } from "@/lib/copy";
import type { Lot } from "@/lib/types";
import { TOTAL_MINUTES, TOTAL_ROUNDS } from "@/lib/auction";

export const metadata: Metadata = {
  title: t.lots.title,
  description: t.lots.lede,
};

/** 9 fills the desktop grid exactly (3×3) and the phone grid evenly (2-up). */
const PAGE_SIZE = 9;

const FILTERS = [
  { key: "all", label: t.lots.filterAll },
  { key: "live", label: t.lots.filterLive },
  { key: "upcoming", label: t.lots.filterUpcoming },
  { key: "results", label: t.lots.filterResults },
] as const;

type FilterKey = (typeof FILTERS)[number]["key"];

/** searchParams values arrive as string | string[] | undefined. */
function one(v: string | string[] | undefined): string | undefined {
  return Array.isArray(v) ? v[0] : v;
}

/**
 * The full catalogue: filter, then page.
 *
 * Both live in the URL rather than in component state, so a page of results can
 * be linked, bookmarked and shared, and the whole thing stays a Server
 * Component with no client JS.
 */
export default async function LotsPage(props: PageProps<"/lots">) {
  const params = await props.searchParams;

  const rawFilter = one(params.filter);
  const filter: FilterKey = FILTERS.some((f) => f.key === rawFilter)
    ? (rawFilter as FilterKey)
    : "all";

  const [live, upcoming, results] = await Promise.all([
    getLiveLots(),
    getUpcomingLots(),
    getResultLots(),
  ]);

  /* Live first in the combined view — it is the only group with a clock. */
  const pools: Record<FilterKey, Lot[]> = {
    all: [...live, ...upcoming, ...results],
    live,
    upcoming,
    results,
  };
  const lots = pools[filter];

  const totalPages = Math.max(1, Math.ceil(lots.length / PAGE_SIZE));
  /* Clamped, so a hand-edited ?page=99 lands on the last page rather than an
     empty grid. */
  const page = Math.min(
    Math.max(1, Number.parseInt(one(params.page) ?? "1", 10) || 1),
    totalPages,
  );

  const from = (page - 1) * PAGE_SIZE;
  const visible = lots.slice(from, from + PAGE_SIZE);

  const makeHref = (p: number) =>
    `/lots?filter=${filter}${p > 1 ? `&page=${p}` : ""}`;

  return (
    <>
      <SiteHeader />

      <main id="main" className="pt-28 md:pt-32">
        <section className="catalogue-hero gutter border-line border-b">
          <div className="catalogue-slate">
            <p className="catalogue-label eyebrow">{t.lots.eyebrow}</p>
            <p className="eyebrow text-[0.5625rem] tracking-[0.12em] sm:text-[0.625rem]">
              {t.brand.tagline}
            </p>
          </div>

          <div className="mt-8 grid items-end gap-8 lg:grid-cols-[1fr_22rem] lg:gap-16">
            <div>
              <h1 className="catalogue-heading display pr-3 text-[clamp(3.5rem,8vw,6.5rem)] leading-none">
                {t.lots.title}
                <span aria-hidden className="text-ink">
                  .
                </span>
              </h1>
              <p className="text-ink-soft mt-5 max-w-xl text-sm leading-relaxed md:text-base">
                {t.lots.lede}
              </p>
            </div>

            <div className="catalogue-summary hidden p-5 lg:block">
              <p className="eyebrow text-accent">{t.home.howItWorks}</p>
              <dl className="mt-5 grid grid-cols-2 gap-5">
                <div>
                  <dt className="eyebrow text-[0.625rem]">
                    {t.home.statRounds}
                  </dt>
                  <dd
                    data-numerals
                    className="text-ink mt-2 text-3xl font-semibold tracking-tight"
                  >
                    {String(TOTAL_ROUNDS).padStart(2, "0")}
                  </dd>
                </div>
                <div>
                  <dt className="eyebrow text-[0.625rem]">
                    {t.home.statDuration}
                  </dt>
                  <dd
                    data-numerals
                    className="text-ink mt-2 text-3xl font-semibold tracking-tight"
                  >
                    {String(Math.floor(TOTAL_MINUTES / 60)).padStart(2, "0")}:
                    {String(TOTAL_MINUTES % 60).padStart(2, "0")}
                    <span className="text-muted ml-2 text-xs font-normal">
                      цаг
                    </span>
                  </dd>
                </div>
              </dl>
              <Link
                href="/rules"
                className="border-line text-accent hover:text-flare mt-5 flex min-h-8 items-center justify-between border-t pt-3 text-xs transition-colors"
              >
                {t.home.ctaSecondary}
                <span aria-hidden>↗</span>
              </Link>
            </div>
          </div>
        </section>

        <section className="gutter py-10 md:py-14">
          {/* Filters. Links, not buttons — each is a real, shareable URL.
              Scrollable on phones so four chips never wrap awkwardly. */}
          {/*
            Scrolls rather than wraps — four chips wrapping to two lines reads
            worse than one line that moves. `scroll-fade` is what makes that
            honest: the row needs 443px and a 320px phone gives it 320, so the
            fourth filter was entirely off-screen with nothing to say so. The
            fade is scoped to the widths where it actually overflows.
          */}
          <div className="scroll-quiet scroll-fade -mx-5 flex gap-1 overflow-x-auto px-5 sm:gap-2 md:mx-0 md:px-0">
            {FILTERS.map((f) => {
              const active = f.key === filter;
              const count = pools[f.key].length;
              return (
                <Link
                  key={f.key}
                  href={`/lots?filter=${f.key}`}
                  aria-current={active ? "page" : undefined}
                  className={`catalogue-filter flex shrink-0 items-center gap-1 border px-2.5 text-[0.7rem] font-medium tracking-[0.06em] uppercase transition-colors sm:gap-1.5 sm:px-4 sm:text-[0.75rem] sm:tracking-[0.08em] ${
                    active
                      ? "border-accent bg-accent text-accent-ink"
                      : "border-line text-ink-soft hover:border-accent hover:text-accent"
                  }`}
                >
                  {f.label}
                  <span
                    data-numerals
                    className={active ? "opacity-60" : "text-faint"}
                  >
                    {count}
                  </span>
                </Link>
              );
            })}
          </div>

          {visible.length === 0 ? (
            /*
              Two different kinds of empty, and saying the wrong one costs a
              visitor. "No lots in this category" is only true when another
              category has some — it invites a click that helps. When the whole
              catalogue is empty it is a lie that sends somebody round all four
              filters before they leave, and right now it is the first thing
              anybody arriving at the site would read.
            */
            <div className="mt-10">
              {pools.all.length === 0 ? (
                <>
                  <p className="text-ink text-base">{t.lots.emptyHouse}</p>
                  <p className="text-muted mt-2 max-w-prose text-sm leading-relaxed">
                    {t.lots.emptyHouseHint}
                  </p>
                  <Link
                    href="/rules"
                    className="eyebrow border-line text-ink hover:border-accent hover:text-accent mt-5 inline-flex h-10 items-center border px-4 transition-colors"
                  >
                    {t.room.rulesLink}
                  </Link>
                </>
              ) : (
                <>
                  <p className="text-muted text-sm">{t.lots.empty}</p>
                  <Link
                    href="/lots?filter=all"
                    className="text-accent mt-3 inline-block text-sm underline underline-offset-4"
                  >
                    {t.lots.emptyOther}
                  </Link>
                </>
              )}
            </div>
          ) : (
            <>
              <p className="catalogue-count eyebrow mt-6" data-numerals>
                {t.lots.showing(from + 1, from + visible.length, lots.length)}
              </p>

              <div className="mt-6 grid grid-cols-2 gap-x-3 gap-y-8 sm:gap-x-6 sm:gap-y-12 lg:grid-cols-3 lg:gap-x-8">
                {visible.map((lot, i) => (
                  /* Stagger by column, not index — otherwise the last card in a
                     nine-item grid waits most of a second. */
                  <Reveal key={lot.id} delay={(i % 3) * 80} y={18}>
                    <LotCard lot={lot} />
                  </Reveal>
                ))}
              </div>

              <Pagination
                page={page}
                totalPages={totalPages}
                makeHref={makeHref}
              />
            </>
          )}
        </section>
      </main>

      <Footer />
    </>
  );
}
